<?php
  $conn = mysqli_connect("localhost", "root", "", "book");
  //session_start();
?>