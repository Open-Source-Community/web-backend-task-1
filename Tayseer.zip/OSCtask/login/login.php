<?php

include '../general/environment.php';
include  '../shared/header.php';
include '../shared/nav.php';
include '../shared/footer.php';
?>
<?php
if(isset($_POST["go"])){
    $name=$_POST["name"];
    $pass=$_POST["password"];
    //$pass=sha1($pass);
    //$pass=$pass;
    $insert="INSERT INTO `persons` VALUES (null,'$name','$pass')";
    $ex=mysqli_query($conn,$insert);
    //if($ex)echo true;

      $select="SELECT * FROM `persons` where  `password`='$pass' ";
      $row=mysqli_query($conn,$select);

      $data=mysqli_fetch_assoc($row);
      


      //echo $data["Name"];
       $_SESSION["user"]=$name;
       $_SESSION["id"]=$data["PersonID"];
       //echo $_SESSION["user"];
      // if(isset($_SESSION["user"]))
    // echo 2;
      //header('Location : /OSCtask/Book/create.php'); 
      header('Location: /OSCtask/Book/create.php/');//
       //echo $_SESSION["user"];   
       //echo $_SESSION["id"];   
      }

?>

<div class="form">

<div  class="container col-6">
    
    <form method="POST" >
      <div class="form-group ">
      <label for="" > Name</label>
        <input type="text" class="form-control" name="name" >
      </div>
      <div class="form-group">
      <label for="">Password </label>
        <input type="password" class="form-control" name ="password">
      </div>
    
      <button type="submit" class="btn btn-primary " name="go">login</button>
    </form>
    
    </div>
    </div>
    </div>


