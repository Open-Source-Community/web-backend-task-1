<?php

include '../general/environment.php';
include  '../shared/header.php';
include '../shared/nav.php';
include '../shared/footer.php';
?>

<?php
if(isset($_GET['edit'])){
  $id=$_GET['edit'];
  $sel="SELECT * FROM book WHERE book_id=$id";
  $update=mysqli_query($conn,$sel);
  $table=mysqli_fetch_assoc($update);

  if(isset($_POST["go"])){
    // echo 2;
       $title=$_POST["title"];
       $description=$_POST["description"];
       $auther=$_POST["auther"];
       //echo $auther;
       $create_time=$_POST["create_time"];
  
       //echo $id;
      
       $fname=time().$_FILES["image"]["name"];
       $temp_name=$_FILES["image"]["tmp_name"];
       $direct='../upload/'.$fname;
       move_uploaded_file($temp_name,$direct);

    $up="UPDATE `book` SET title='$title' ,description=' $description',auther='$auther',`image`='$direct'
    WHERE book_id=$id";
     $r= mysqli_query($conn,$up);

    if($r)echo true;
    header('Location:/OSCtask/Book/read.php');
       }



}

?>

<div class="form">

<div  class="container col-6">
    
    <form method="POST" enctype="multipart/form-data">
      
      <div class="form-group">
      <label for="">Auther</label>
        <input type="text" class="form-control"  name ="auther" value="<?=(isset($table["auther"]))?
        $table["auther"]:''?>"> 
      </div>

      <div class="form-group ">
      <label for="" >Title</label>
        <input type="text" class="form-control" name="title" value="<?=(isset($table['title']))?
        $table['title']:''?>"> 
      </div>


      <div class="form-group">
      <label for="">Description</label>
        <input type="text" class="form-control" name ="description" value="<?=(isset($table['description']))?
        $table['description']:''?>"> 
      </div>


      <div class="form-group">
      <label for="">Create Time</label>
        <input type="text" class="form-control"  name ="create_time" value="<?=(isset($table['publication_date']))?
        $table["publication_date"]:''?>"> 
      </div>


      <div class="form-group">
      <label for="">Image</label>
      <img src="<?=$table["image"]?>" alt="" width =100>
     <input type="file"  name="image"> 
      </div >

      <button type="submit" class="btn btn-primary " name="go">Submit</button>
    </form>
    
    </div>
    </div>