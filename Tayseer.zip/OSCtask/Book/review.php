<?php

include '../general/environment.php';
include  '../shared/header.php';
include '../shared/nav.php';
include '../shared/footer.php';



if(isset($_POST["go"])){
  
    $content=$_POST["content"];
    $id=$_GET["id"];
             
        $insert="INSERT INTO `review` VALUES (null,$id,'$content')";
        $r=mysqli_query($conn,$insert);
        //if($r)echo 1;
    }
?>


<div class="form">
    
    <div  class="container col-6">
        
        <form method="POST" >
          <div class="form-group ">
          <label for="" >WRIRE REVIREW HERE</label>
            <input type="text" class="form-control" name="content" >
          </div>
    
          <button type="submit" class="btn btn-primary " name="go">Submit</button>
        </form>
        
        </div>
                
        </div>
        </div>
    