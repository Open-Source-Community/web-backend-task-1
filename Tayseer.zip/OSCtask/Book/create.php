<?php

include '../general/environment.php';
include  '../shared/header.php';
include '../shared/nav.php';
include '../shared/footer.php';

?>

<?php
if(isset($_POST["go"])){

  //echo $_SESSION["id"];
 //print_r($_SESSION);
       $title=$_POST["title"];
       $description=$_POST["description"];
       $auther= $_SESSION["user"];
       $id= $_SESSION["id"];
       $fname=time().$_FILES["image"]["name"];
       $temp_name=$_FILES["image"]["tmp_name"];
       $direct='../upload/'.$fname;
       move_uploaded_file($temp_name,$direct);
                
           $insert="INSERT INTO `book` VALUES (null,'$id','$title','$auther','$description',CURRENT_TIMESTAMP(), '$direct')";
           $r=mysqli_query($conn,$insert);
           //if($r)echo 1;
           header('Location: /OSCtask/Book/read.php/');//
       }
?>



<div class="form">
    
    <div  class="container col-6">
        
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group ">
          <label for="" >title</label>
            <input type="text" class="form-control" name="title" >
          </div>

          <div class="form-group">
          <label for="">description</label>
            <input type="text" class="form-control" name ="description">
          </div>
       

          <div class="form-group">
          <label for="">upload photo</label>
          <input type="file" name="image">
          </div >
    
          <button type="submit" class="btn btn-primary " name="go">Submit</button>
        </form>
        
        </div>
                
        </div>
        </div>
    