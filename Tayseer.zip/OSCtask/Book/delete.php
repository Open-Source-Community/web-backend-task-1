<?php

$con=mysqli_connect("localhost", "root", "", "book");
$id=$_GET['delete'];

$del1="DELETE FROM review WHERE book_id= $id ";
mysqli_query($con,$del1);

$del="DELETE FROM book WHERE book_id= $id ";
$R=mysqli_query($con,$del);
if($R)echo 1;
header('Location:/OSCtask/Book/read.php');
?>
