<?php

include '../general/environment.php';
include  '../shared/header.php';
include '../shared/nav.php';
include '../shared/footer.php';
?>


<?php
if(isset($_SESSION["title"]))
{
    $t=$_SESSION["title"];
    $select="SELECT * FROM book  WHERE `title`='$t'";
    $data=mysqli_query($conn,$select);
    $data=mysqli_fetch_assoc($data);

}
?>

</table>

<div >
<table class="table table-dark">

    <tr>
    <td>Title</td>
    <td><?=$data["title"]?></td>
    </tr>

    <tr>
    <td>Description</td>
    <td><?=$data["description"]?></td> 
    </tr>

   

    <td>Create Time</td>
    <td><?=$data["publication_date"]?></td> 

    

    <tr>
    <td>Auther</td>
    <td><?=$data["auther"]?></td>
    </tr>


</table>