<?php

include '../general/environment.php';
include  '../shared/header.php';
include '../shared/nav.php';
include '../shared/footer.php';
?>


<?php
$select="SELECT * FROM book ";
$row=mysqli_query($conn,$select);
?>

</table>

<div >
<table class="table table-dark">


<?php foreach($row as $data){ ?>
    <tr>
    <td>Title</td>
    <td><?=$data["title"]?></td>
    </tr>

    <tr>
    <td>Description</td>
    <td><?=$data["description"]?></td> 
    </tr>

   

    <td>Create Time</td>
    <td><?=$data["publication_date"]?></td> 

    

    <tr>
    <td>Auther</td>
    <td><?=$data["auther"]?></td>
    </tr>

    <tr>
   <td>Image</td>
   <td><img src="<?=$data["image"]?> " width="100" alt=""></td>
   </tr

<tr>
<td>
<a class="btn btn-danger" href="./delete.php?delete=<?=$data['book_id']?>">DELETE</a>
 <a class="btn btn-success"  href="./update.php?edit=<?=$data['book_id']?>"> UPDATE </a>
 <a class="btn btn-primary"  href="./review.php?id=<?=$data['book_id']?>"> REVIEW </a>

</td>
 
</tr>
<?php } ?>
</table>